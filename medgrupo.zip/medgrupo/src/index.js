$(function () {
 $('.mobile--click').click(function(){
	$('.mobile--click').toggleClass('mobile--active');
	$('.landing--area--header').toggleClass('landing--area--active');
 });
 
});